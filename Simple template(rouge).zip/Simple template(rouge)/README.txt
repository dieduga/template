README
Ceci est un template pour la création de sites web à destination d'étudiants souhaitant présenter leurs projets.
Il a été conçu pour être éco-responsable, c'est-à-dire en limitant au maximum la consommation du site web
Le site web est conçu avec le langage de balise HTML, ainsi qu'avec le langage CSS.


Le langage HTML fonctionne sous forme de balises (<body></body>), une page est constitué d'éléments spéciaux tels que le body(corps du texte), le head(l'en-tête), le footer(pied de page)
Dans ces balises, vont apparaître d'autres balises, comme la balise div (permettant de séparer les éléments), les balises h(ajouter un titre), ul(liste non ordonnée), li(éléments de liste), a(pour créer un lien), img(pour intégrer une image)


La page web, est organisé dans un dossier contenant le code HTML (index.html), ainsi qu'un dossier images(dans lequel il faut mettre les images qu'on souhaitent intégrer), il y a également un dossier layout(application de styles, positionnement, police) et enfin un dossier pages(contenant les autres pages du site web)


Pour la personnalisation, du template il s'agit surtout de changer les textes (titres, listes, paragraphes) ainsi que les images
Il suffit donc de changer les textes dans les balises associées en les remplaçant par son texte (balises concernées : h(1,2,3,etc), ul, li, p)
Pour les images, il faut remplacer les liens (relatifs) dans le paramètre "src" de la balise <img> pour qu'elles soient visibles par tous

Pour être sûr que l'image soit visible par tout le monde, il faut mettre le lien relatif de l'image : images/demo/"lien de l'image"
"images/demo" étant le chemin d'accès aux images. Il est donc nécessaire de bien insérer l'image dans le dossier avant de copier son chemin d'accès.

Documentation langage HTML : https://developer.mozilla.org/fr/docs/Web/HTML